---
Last Updated: 2025-10-03
Owner: DevOps Team
Review Cadence: Monthly
---

# Deprecated: See docs/DEPLOYMENT.md

<!-- TOC -->

- [Contents moved](#contents-moved)
<!-- /TOC -->

This document has been consolidated into [DEPLOYMENT.md](./DEPLOYMENT.md).

## Contents moved

- Quick deployment options
- Local services management (embedder, reranker, extraction)
- Cloud-first vs self-hosted architecture decisions

Please update any bookmarks or references to use the new path.

Please update any bookmarks or references to use the new path.
