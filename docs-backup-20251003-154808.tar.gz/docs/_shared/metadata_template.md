---
Last Updated: 2025-10-03
Owner: Team Name
Review Cadence: Monthly
---

# Document Title

Brief description of the document’s purpose and scope.

Guidelines

- Place this front matter at the top of Markdown docs.
- Keep the “Last Updated” date current when making meaningful changes.
- Choose a realistic review cadence and honor it.
